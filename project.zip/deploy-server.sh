#!/bin/bash

# 服务器部署脚本
echo "开始部署网站..."

# 备份当前网站
echo "备份当前网站..."
sudo cp -r /var/www/douyin-admin-master /var/www/douyin-admin-master.backup.$(date +%Y%m%d_%H%M%S)

# 解压新文件
echo "解压新文件..."
cd /var/www
sudo unzip -o dist.zip -d douyin-admin-master/

# 设置权限
echo "设置文件权限..."
sudo chown -R www-data:www-data /var/www/douyin-admin-master
sudo chmod -R 755 /var/www/douyin-admin-master

# 重启web服务器（如果需要）
echo "重启web服务器..."
sudo systemctl restart nginx

echo "部署完成！"
echo "网站已更新到最新版本"
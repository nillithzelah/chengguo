## 组件说明

该组件非官方最终设计规范，以单独组件存在。

同时仅仅提供最基本的功能，后续进行优化及更改。


## Component description

The component unofficial final design specification exists as a separate component.

At the same time, only the most basic functions are provided, and subsequent optimizations and changes will be made.
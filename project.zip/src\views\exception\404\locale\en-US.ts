export default {
  'menu.exception.404': '404',
  'exception.result.404.description': 'Whoops, this page is gone.',
  'exception.result.404.retry': 'Retry',
  'exception.result.404.back': 'Back',
};

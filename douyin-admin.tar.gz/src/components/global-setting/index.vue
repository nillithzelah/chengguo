<template>
  <div class="global-setting">
    <h2>全局设置</h2>
    <p>这里是全局设置页面内容</p>
  </div>
</template>

<script setup lang="ts">
// 全局设置组件
</script>

<style scoped>
.global-setting {
  padding: 20px;
}
</style>